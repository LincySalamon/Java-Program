package com.FileHandling;

import org.json.JSONObject;

public class ExampleJson {

	public static void main(String[] args) {
		// TODO Auto-generated method stub 
		JSONObject obj = new JSONObject();
		
		String str = "987767";
		int val = Integer.parseInt(str); 
		System.out.println(val);

	}

}
